#pragma once

#include <cstdint>
#include <deque>
#include <string>

#include "coreflow/baseline_intelligence.hpp"
#include "coreflow/config.hpp"
#include "coreflow/context.hpp"
#include "coreflow/control.hpp"
#include "coreflow/resource_model.hpp"
#include "coreflow/resource_mutation.hpp"
#include "coreflow/controller.hpp"
#include "coreflow/discovery.hpp"
#include "coreflow/experience.hpp"
#include "coreflow/mutation.hpp"
#include "coreflow/mutation_journal.hpp"
#include "coreflow/safety_hold.hpp"
#include "coreflow/status_snapshot.hpp"
#include "coreflow/observer.hpp"
#include "coreflow/policy.hpp"
#include "coreflow/types.hpp"
#include "coreflow/thermal_predictor.hpp"
#include "coreflow/thermal_guard.hpp"

namespace coreflow {

class AutonomousEngine {
public:
    AutonomousEngine();
    ~AutonomousEngine();

    AutonomousEngine(const AutonomousEngine&) = delete;
    AutonomousEngine& operator=(const AutonomousEngine&) = delete;

    int run();

private:
    bool initialize();
    bool refreshEnvironment();
    void tick();
    void logStartup() const;
    void logStateTransition(RuntimeState, RuntimeState) const;
    void logMutation(MutationResult, RuntimeState) const;
    // Best-effort export of what the engine sees, decides and changed, for the WebUI.
    // It carries no authority and a failure here never affects control.
    void publishStatus(const RuntimeSample&, RuntimeState previous, RuntimeState next,
                       Decision, const SystemContext&, const PolicyPlan&, HoldReason,
                       MutationResult cpu, MutationResult resource) noexcept;
    void publishStoppedStatus() noexcept;

    bool has_restored_{false};
    bool refresh_pending_{false};
    bool validateSample(const RuntimeSample&) const;
    void updateTrends(RuntimeSample&) const;
    double calculateConfidence(const RuntimeSample&) const;
    NotificationEvent selectNotification(
        const RuntimeSample&, RuntimeState, RuntimeState
    ) const;
    void emitNotification(NotificationEvent, const RuntimeSample&) const;

    EngineConfig config_;
    MutationMode configured_mode_{MutationMode::Disabled};
    bool configured_armed_{false};
    HoldReason hold_reason_{HoldReason::None};
    bool last_context_eligible_{false};
    FileMutationJournal journal_;
    FileMutationJournal resource_journal_;
    MutationController controller_;
    ResourceMutationController resource_controller_;
    EnvironmentDiscovery discovery_;
    RuntimeObserver observer_;
    AdaptivePolicy policy_;
    ContextEngine context_engine_;
    PolicyEngine policy_engine_;
    MutationAuthority mutation_authority_;
    ResourceStateModel resource_model_;
    EngineSnapshot snapshot_;
    std::uint64_t sample_count_{0};
    std::deque<RuntimeSample> history_;
    std::uint64_t last_notification_sample_{0};
    NotificationEvent last_notification_{NotificationEvent::None};
    BaselineIntelligence baseline_intelligence_;
    ExperienceMemory experience_memory_;
    ThermalPredictor thermal_predictor_;
    std::uint64_t mutation_cooldown_until_sample_{0};
    ThermalGuardState thermal_guard_state_{};

    EngineStatus last_status_;
    std::uint64_t status_verified_{0};
    std::uint64_t status_rolled_back_{0};
    std::uint64_t status_failed_{0};
    std::uint64_t last_change_sample_{0};
    std::string last_change_kind_;
    std::string last_change_result_;
};

} // namespace coreflow
